package mono.embeddinator.android;

public interface IJavaCallback {
    void send(String text);
}